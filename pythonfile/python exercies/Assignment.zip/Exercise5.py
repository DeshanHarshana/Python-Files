for i in range(100, 10, -20):
    print((100-i)//20)
