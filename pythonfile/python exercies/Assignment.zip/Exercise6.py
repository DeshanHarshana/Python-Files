for e in [13, 6, 28, 22, 5, 92]:
    print(e, ' mod ', 7, ' = ', e % 7)
