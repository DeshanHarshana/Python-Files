product = [(i, j) for i in range(1, 4) for j in range(2, 10, 2)]
print(product)

#output
#[(1, 2), (1, 4), (1, 6), (1, 8), (2, 2), (2, 4), (2, 6), (2, 8), (3, 2), (3, 4), (3, 6), (3, 8)]