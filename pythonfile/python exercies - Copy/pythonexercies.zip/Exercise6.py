for e in [13, 6, 28, 22, 5, 92]:
    print(e, ' mod ', 7, ' = ', e % 7)

'''
output
13  mod  7  =  6
6  mod  7  =  6
28  mod  7  =  0
22  mod  7  =  1
5  mod  7  =  5
92  mod  7  =  1

'''
