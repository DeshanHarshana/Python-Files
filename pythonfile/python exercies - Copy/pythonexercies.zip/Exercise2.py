num_list = [13, 6, 58, 5, 7, 96, 1, 8, 39]
even_num = [number for number in num_list if number % 2 == 0]
print(even_num)
