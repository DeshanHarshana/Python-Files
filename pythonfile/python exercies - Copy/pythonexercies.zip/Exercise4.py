for i in range(0, 1):
    print(i)
#output is 0