print('---------------')
for i in range(5):
    print(i, end=",")
print('\n---------------')
for i in range(-5, 0):
    print(i, end=",")
print('\n---------------')
for i in range(3, 24, 7):
    print(i, end=",")
print('\n---------------')
for i in range(24, 3, -7):
    print(i, end=",")
print('\n---------------')
