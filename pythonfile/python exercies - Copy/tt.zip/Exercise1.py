marks=[35, 38, 39, 40, 45]
for mark in marks:
    if (mark > 39): grade = 'Pass'
    else: grade = 'Fail'
    print("The result for", mark, 'is', grade)