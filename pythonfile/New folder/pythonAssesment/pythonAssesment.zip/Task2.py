n = int(input("Enter SIze : "))
if n > 2:
    for i in range(0, n):
        if(i == 0 or i == n-1):
            for j in range(n):
                print('✲', end='')
            print()
        elif(i>0 and i<n-1):
            print('✲', end='')
            for j in range(0,n-2):
                print('·', end='')
            print('✲', end='')
            print()
                
       
       
