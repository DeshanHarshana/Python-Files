n = int(input("Enter SIze : "))
for i in range(n):
    for j in range(n):
        print('*', end='')
    print()
